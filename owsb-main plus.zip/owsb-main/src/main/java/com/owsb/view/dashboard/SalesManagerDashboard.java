package com.owsb.view.dashboard;

import com.owsb.controller.AuthController;
import com.owsb.model.User;
import com.owsb.model.user.SalesManager;
import com.owsb.util.Constants;
import com.owsb.util.FileUtils;
import com.google.gson.*;
import com.owsb.util.ItemsStat;
import com.owsb.util.SupplierStat;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;

/**
 * Dashboard for Sales Managers
 * Extends BaseDashboard and adds role-specific functionality
 */
public class SalesManagerDashboard extends BaseDashboard {
    
    // Specific components for SalesManager
    private JPanel itemPanel;
    private JPanel supplierPanel;
    private JPanel salesPanel;
    private JPanel requisitionPanel;
    
    /**
     * Constructor for SalesManagerDashboard
     * @param user Current logged in user (should be SalesManager)
     * @param authController Authentication controller
     */
    public SalesManagerDashboard(User user, AuthController authController) {
        super("OWSB - Sales Manager Dashboard", user, authController);
        
        // Check if user is a SalesManager
        if (!(user instanceof SalesManager)) {
            throw new IllegalArgumentException("User must be a Sales Manager");
        }
    }
    
    /**
     * Override role-specific greeting
     * @return Sales Manager specific greeting
     */
    @Override
    protected String getRoleSpecificGreeting() {
        SalesManager salesManager = (SalesManager) currentUser;
        return salesManager.getSalesGreeting();
    }
    
    /**
     * Initialize Sales Manager specific components
     */
    @Override
    protected void initRoleComponents() {
        // Initialize panel placeholders
        initPanels();
        
        // Add menu buttons for Sales Manager functions
        addMenuButton("Manage Items", e -> showItemPanel());
        addMenuButton("Manage Suppliers", e -> showSupplierPanel());
        addMenuButton("Daily Sales Entry", e -> showSalesPanel());
        addMenuButton("Purchase Requisitions", e -> showRequisitionPanel());
        addMenuButton("View Purchase Orders", e -> viewPurchaseOrders());
    }
    
    /**
     * Initialize panel placeholders
     */
    private void initPanels() {
        // Item management panel
        itemPanel = new JPanel(new BorderLayout());
        JLabel itemLabel = new JLabel("Item Management", JLabel.CENTER);
        itemLabel.setFont(new Font("Arial", Font.BOLD, 18));
        itemPanel.add(itemLabel, BorderLayout.NORTH);
        
        JPanel itemContent = createItemContent();
        itemPanel.add(itemContent, BorderLayout.CENTER);
        
        // Supplier management panel
        supplierPanel = new JPanel(new BorderLayout());
        JLabel supplierLabel = new JLabel("Supplier Management", JLabel.CENTER);
        supplierLabel.setFont(new Font("Arial", Font.BOLD, 18));
        supplierPanel.add(supplierLabel, BorderLayout.NORTH);
        
        JPanel supplierContent = createSupplierContent();
        supplierPanel.add(supplierContent, BorderLayout.CENTER);
        
        // Sales entry panel
        salesPanel = new JPanel(new BorderLayout());
        JLabel salesLabel = new JLabel("Daily Sales Entry", JLabel.CENTER);
        salesLabel.setFont(new Font("Arial", Font.BOLD, 18));
        salesPanel.add(salesLabel, BorderLayout.NORTH);
        
        JPanel salesContent = createSalesContent();
        salesPanel.add(salesContent, BorderLayout.CENTER);
        
        // Purchase requisition panel
        requisitionPanel = new JPanel(new BorderLayout());
        JLabel requisitionLabel = new JLabel("Purchase Requisitions", JLabel.CENTER);
        requisitionLabel.setFont(new Font("Arial", Font.BOLD, 18));
        requisitionPanel.add(requisitionLabel, BorderLayout.NORTH);
        
        JPanel requisitionContent = createRequisitionContent();
        requisitionPanel.add(requisitionContent, BorderLayout.CENTER);
    }
    
    /**
     * Create item management content
     * @return Item management panel
    
    /**
     * Create supplier management content
     * @return Supplier management panel
     */
private void loadItemsFromFile(DefaultTableModel model) {
    try {
        Gson gson = new Gson();
        FileReader reader = new FileReader(Constants.INVENTORY_FILE);
        ItemsStat[] items = gson.fromJson(reader, ItemsStat[].class);
        reader.close();

        if (items != null) {
            for (ItemsStat item : items) {
                model.addRow(new Object[]{
                    item.getItemID(),
                    item.getItemName(),
                    item.getStock()
                });
            }
        }
    } catch (IOException e) {
        System.err.println("Could not load items from file: " + e.getMessage());
    }
}

private void loadISuppliersFromFile(DefaultTableModel model) {
    try {
        Gson gson = new Gson();
        FileReader reader = new FileReader(Constants.SUPPLIER_FILE);
        SupplierStat[] sups = gson.fromJson(reader, SupplierStat[].class);
        reader.close();

        if (sups != null) {
            for (SupplierStat sup : sups) {
                model.addRow(new Object[]{
                    sup.getSupplierID(),
                    sup.getSupplierName(),
                    sup.getContact()
                });
            }
        }
    } catch (IOException e) {
        System.err.println("Could not load items from file: " + e.getMessage());
    }
}

private int getLastItemCodeFromFile() {
    int maxCode = 0;
    File file = new File(Constants.INVENTORY_FILE);

    if (file.exists()) {
        try (Reader reader = new FileReader(file)) {
            Gson gson = new Gson();
            ItemsStat[] items = gson.fromJson(reader, ItemsStat[].class);

            if (items != null) {
                for (ItemsStat item : items) {
                    String id = item.getItemID();
                    if (id != null && id.startsWith("IT")) {
                        try {
                            int num = Integer.parseInt(id.substring(2));
                            if (num > maxCode) {
                                maxCode = num;
                            }
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading inventory file: " + e.getMessage());
        }
    }

    return maxCode;
}

private int getLastSupplierCodeFromFile() {
    int maxCode = 0;
    File file = new File(Constants.SUPPLIER_FILE);

    if (file.exists()) {
        try (Reader reader = new FileReader(file)) {
            Gson gson = new Gson();
            SupplierStat[] sup = gson.fromJson(reader, SupplierStat[].class);

            if (sup != null) {
                for (SupplierStat item : sup) {
                    String id = item.getSupplierID();
                    if (id != null && id.startsWith("SUP")) {
                        try {
                            int num = Integer.parseInt(id.substring(2));
                            if (num > maxCode) {
                                maxCode = num;
                            }
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading inventory file: " + e.getMessage());
        }
    }

    return maxCode;
}

private int lastCode = 0;
private String generateNextItemCode() {
    if (lastCode == 0) {
        lastCode = getLastItemCodeFromFile();
    }
    lastCode++;
    return String.format("IT%03d", lastCode);
}

private String generateNextSupplierCode() {
    if (lastCode == 0) {
        lastCode = getLastSupplierCodeFromFile();
    }
    lastCode++;
    return String.format("SUP%03d", lastCode);
}


private JPanel createItemContent() {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    // Simple form for item entry
    JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));

    JLabel itemCodeLabel = new JLabel(); // Auto-generated code
    JTextField t2 = new JTextField();    // Item name
    JTextField t3 = new JTextField();    // Stock

    formPanel.add(new JLabel("Item Code:"));
    formPanel.add(itemCodeLabel);
    formPanel.add(new JLabel("Item Name:"));
    formPanel.add(t2);
    formPanel.add(new JLabel("Current Stock:"));
    formPanel.add(t3);

    // Buttons
    JPanel buttonPanel = new JPanel();
    JButton itemsintotable = new JButton("Add Item");
    JButton itemsintotextfile = new JButton("Save to File");
    JButton itemsdeletefromtextfile = new JButton("Delete Item");

    buttonPanel.add(itemsintotable);
    buttonPanel.add(itemsintotextfile);
    buttonPanel.add(itemsdeletefromtextfile);

    // Table
    DefaultTableModel model = new DefaultTableModel(new Object[]{"Item Code", "Item Name", "Current Stock"}, 0);
    JTable itemTable = new JTable(model);
    itemTable.setDefaultEditor(Object.class, null);
    JScrollPane scrollPane = new JScrollPane(itemTable);
    itemCodeLabel.setText(generateNextItemCode());
    
    // Add Item
    itemsintotable.addActionListener((ActionEvent e) -> {
        String code = itemCodeLabel.getText();
        String name = t2.getText().trim();
        String stockText = t3.getText().trim();

        if (name.isEmpty() || stockText.isEmpty()) {
            JOptionPane.showMessageDialog(panel, "Please fill in all fields.");
            return;
        }

        int stock = Integer.parseInt(stockText);
        model.addRow(new Object[]{code, name, stock});
        t2.setText("");
        t3.setText("");
        itemCodeLabel.setText(generateNextItemCode());
    });

    // Save to file
    itemsintotextfile.addActionListener((ActionEvent e) -> {
       java.util.List<ItemsStat> items = new java.util.ArrayList<>();
        for (int i = 0; i < itemTable.getRowCount(); i++) {
            items.add(new ItemsStat(
                itemTable.getValueAt(i, 0).toString(),
                itemTable.getValueAt(i, 1).toString(),
                Integer.parseInt(itemTable.getValueAt(i, 2).toString())
            ));
        }

        AuthController at = new AuthController();
        boolean success = at.saveItemsToFile(items);
        if (success) {
            System.out.println("Inventory successfully saved!");
        } else {
            System.err.println("Failed to save inventory.");
        }
    });

    itemsdeletefromtextfile.addActionListener((ActionEvent e) -> {
    int selectedRow = itemTable.getSelectedRow();

    if (selectedRow != -1) {
        String itemIDToDelete = itemTable.getValueAt(selectedRow, 0).toString();

        try {
            Gson gson = new Gson();
            FileReader reader = new FileReader(Constants.INVENTORY_FILE);
            ItemsStat[] itemArray = gson.fromJson(reader, ItemsStat[].class);
            reader.close();

            java.util.List<ItemsStat> deleteditems = new java.util.ArrayList<>();
            for (ItemsStat item : itemArray) {
                if (!item.getItemID().equals(itemIDToDelete)) {
                    deleteditems.add(item);
                }
            }

            FileWriter writer = new FileWriter(Constants.INVENTORY_FILE);
            gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(deleteditems, writer);
            writer.close();

            ((DefaultTableModel) itemTable.getModel()).removeRow(selectedRow);

            System.out.println("Item deleted: " + itemIDToDelete);
        } catch (IOException ex) {
            System.err.println("Error deleting item: " + ex.getMessage());
        }
    } else {
        System.out.println("No row selected for deletion.");
    }
});

    // Combine components
    panel.add(formPanel, BorderLayout.NORTH);
    panel.add(buttonPanel, BorderLayout.CENTER);
    panel.add(scrollPane, BorderLayout.SOUTH);
    
    loadItemsFromFile(model);
    return panel;
}

    private JPanel createSupplierContent() {
        // Similar structure to item panel but with supplier fields
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        
        JLabel itemSupplierLabel = new JLabel(); // Auto-generated code
        JTextField t2 = new JTextField();
        JTextField t3 = new JTextField();
        
        formPanel.add(new JLabel("Item Code:"));
        formPanel.add(itemSupplierLabel);
        
        formPanel.add(new JLabel("Supplier Name:"));
        formPanel.add(t2);
        
        formPanel.add(new JLabel("Contact:"));
        formPanel.add(t3);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(new JButton("Add Supplier"));
        buttonPanel.add(new JButton("Update Supplier"));
        buttonPanel.add(new JButton("Delete Supplier"));
        
        //call button based on which was written first
        JButton suppliersintotable = (JButton) buttonPanel.getComponent(0);
        JButton suppliersintotextfile = (JButton) buttonPanel.getComponent(1);
        JButton suppliersdeletefromtextfile = (JButton) buttonPanel.getComponent(2);
       
        
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Supplier Code", "Supplier Name", "Contact"}, 0);
        JTable supplierTable = new JTable(model);
        supplierTable.setDefaultEditor(Object.class, null); // Make table non-editable
        JScrollPane scrollPane = new JScrollPane(supplierTable);
        itemSupplierLabel.setText(generateNextSupplierCode());

        suppliersintotable.addActionListener((ActionEvent e) -> {
            String code = itemSupplierLabel.getText();
            String name = t2.getText().trim();
            String contact = t3.getText().trim();

            if (name.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Please fill in all fields.");
                return;
            }

            int stock = Integer.parseInt(contact);
            model.addRow(new Object[]{code, name, stock});
            t2.setText("");
            t3.setText("");
            itemSupplierLabel.setText(generateNextSupplierCode());
        });
        
        suppliersdeletefromtextfile.addActionListener((ActionEvent e) -> {
            int selectedRow = supplierTable.getSelectedRow();

            if (selectedRow != -1) {
            String supplierIDToDelete = supplierTable.getValueAt(selectedRow, 0).toString();

            try {
                Gson gson = new Gson();
                FileReader reader = new FileReader(Constants.SUPPLIER_FILE);
                SupplierStat[] suppliers = gson.fromJson(reader, SupplierStat[].class);
                reader.close();

                java.util.List<SupplierStat> updatedSuppliers = new java.util.ArrayList<>();
                for (SupplierStat sup : suppliers) {
                    if (!sup.getSupplierID().equals(supplierIDToDelete)) {
                        updatedSuppliers.add(sup);
                    }
                }

                FileWriter writer = new FileWriter(Constants.SUPPLIER_FILE);
                gson = new GsonBuilder().setPrettyPrinting().create();
                gson.toJson(updatedSuppliers, writer);
                writer.close();

                ((DefaultTableModel) supplierTable.getModel()).removeRow(selectedRow);
                System.out.println("Supplier deleted: " + supplierIDToDelete);

            } catch (IOException ex) {
                System.err.println("Error deleting supplier: " + ex.getMessage());
            }
        } else {
            System.out.println("No row selected for deletion.");
        }
    });
        
        suppliersintotextfile.addActionListener((ActionEvent e) -> {
            java.util.List<SupplierStat> items = new java.util.ArrayList<>();
                for (int i = 0; i < supplierTable.getRowCount(); i++) {
                    SupplierStat item = new SupplierStat(
                    supplierTable.getValueAt(i, 0).toString(), // supID
                    supplierTable.getValueAt(i, 1).toString(), // supName
                    Integer.parseInt(supplierTable.getValueAt(i, 2).toString())  // number
                );
                items.add(item);
            }

            AuthController at = new AuthController();
            boolean success = at.saveSuppliersToFile(items);
        if (success) {
            System.out.println("Supplier successfully saved!");
        } else {
            System.err.println("Failed to save supplier.");
        }
            });
        
        // Combine components
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER); 
        panel.add(scrollPane, BorderLayout.SOUTH);
        
        loadISuppliersFromFile(model);
        return panel;
    }
    
    /**
     * Create sales entry content
     * @return Sales entry panel
     */
    private JPanel createSalesContent() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Form for daily sales entry
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        
        formPanel.add(new JLabel("Date:"));
        formPanel.add(new JTextField(new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date())));
        
        formPanel.add(new JLabel("Item Code:"));
        JComboBox<String> itemCombo = new JComboBox<>(new String[]{"IT001", "IT002", "IT003"});
        formPanel.add(itemCombo);
        
        formPanel.add(new JLabel("Quantity Sold:"));
        formPanel.add(new JTextField());
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(new JButton("Record Sale"));
        buttonPanel.add(new JButton("View Sales Report"));
        
        // Mock sales table
        String[] columnNames = {"Date", "Item Code", "Item Name", "Quantity Sold"};
        Object[][] data = {
            {"2025-03-28", "IT001", "Rice 5kg", 10},
            {"2025-03-28", "IT002", "Sugar 1kg", 15},
            {"2025-03-27", "IT003", "Flour 1kg", 8}
        };
        
        JTable salesTable = new JTable(data, columnNames);
        salesTable.setDefaultEditor(Object.class, null); // Make the table non-editable
        JScrollPane scrollPane = new JScrollPane(salesTable);
        
        // Combine components
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Create purchase requisition content
     * @return Purchase requisition panel
     */
    private JPanel createRequisitionContent() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Form for creating PRs
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        
        formPanel.add(new JLabel("Item Code:"));
        JComboBox<String> itemCombo = new JComboBox<>(new String[]{"IT001", "IT002", "IT003"});
        formPanel.add(itemCombo);
        
        formPanel.add(new JLabel("Quantity:"));
        formPanel.add(new JTextField());
        
        formPanel.add(new JLabel("Required Date:"));
        formPanel.add(new JTextField(new java.text.SimpleDateFormat("yyyy-MM-dd").format(
            new java.util.Date(System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000)))); // 1 week from now
        
        formPanel.add(new JLabel("Supplier:"));
        JComboBox<String> supplierCombo = new JComboBox<>(new String[]{"SUP001", "SUP002"});
        formPanel.add(supplierCombo);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(new JButton("Create Requisition"));
        buttonPanel.add(new JButton("View Requisitions"));
        
        // Mock PR table
        String[] columnNames = {"PR ID", "Date", "Item Code", "Quantity", "Required Date", "Status"};
        Object[][] data = {
            {"PR001", "2025-03-25", "IT001", 50, "2025-04-05", "NEW"},
            {"PR002", "2025-03-26", "IT002", 100, "2025-04-10", "PROCESSED"},
            {"PR003", "2025-03-27", "IT003", 30, "2025-04-15", "REJECTED"}
        };
        
        JTable prTable = new JTable(data, columnNames);
        prTable.setDefaultEditor(Object.class, null); // Make the table non-editable
        JScrollPane scrollPane = new JScrollPane(prTable);
        
        // Combine components
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Show item management panel
     */
    private void showItemPanel() {
        setContent(itemPanel);
        setStatus("Item Management");
    }
    
    /**
     * Show supplier management panel
     */
    private void showSupplierPanel() {
        setContent(supplierPanel);
        setStatus("Supplier Management");
    }
    
    /**
     * Show sales entry panel
     */
    private void showSalesPanel() {
        setContent(salesPanel);
        setStatus("Daily Sales Entry");
    }
    
    /**
     * Show requisition panel
     */
    private void showRequisitionPanel() {
        setContent(requisitionPanel);
        setStatus("Purchase Requisitions");
    }
    
    /**
     * View purchase orders
     */
    private void viewPurchaseOrders() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel label = new JLabel("Purchase Orders", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(label, BorderLayout.NORTH);
        
        // Mock PO table (view only for Sales Managers)
        String[] columnNames = {"PO ID", "Date", "PR ID", "Item Code", "Quantity", "Status"};
        Object[][] data = {
            {"PO001", "2025-03-26", "PR001", "IT001", 50, "PENDING"},
            {"PO002", "2025-03-27", "PR002", "IT002", 100, "APPROVED"},
            {"PO003", "2025-03-28", "PR003", "IT003", 30, "REJECTED"}
        };
        
        JTable poTable = new JTable(data, columnNames);
        poTable.setDefaultEditor(Object.class, null); // Make the table non-editable
        JScrollPane scrollPane = new JScrollPane(poTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        setContent(panel);
        setStatus("Viewing Purchase Orders");
    }
}