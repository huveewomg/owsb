package com.owsb.util;

public class ItemsStat {
    private String itemID;
    private String itemName;
    private int stock;
    //private double unitPrice;
    //private String category;
    //private String supplierID;
    //private String dateAdded;
    
    
    /*public ItemSupplier(String itemID, String name, int stock, String description, double unitPrice,
                String category, String supplierID, String dateAdded)*/
    public ItemsStat(String itemID, String name, int stock){
        this.itemID = itemID;
        this.itemName = name;
        this.stock = stock;
        //this.unitPrice = unitPrice;
        //this.category = category;
        //this.supplierID = supplierID;
        //this.dateAdded = dateAdded;
    }
    
    public String getItemID() {
        return itemID;
    }
    
    public String getItemName() {
        return itemName;
    }
    
    public int getStock() {
        return stock;
    }
}
