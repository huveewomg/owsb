package com.owsb.util;

public class SupplierStat {
    private String supplierID;
    private String supplierName;
    private int contact;
    //private double unitPrice;
    //private String category;
    //private String supplierID;
    //private String dateAdded;

    
    /*public ItemSupplier(String itemID, String name, int stock, String description, double unitPrice,
                String category, String supplierID, String dateAdded)*/
    public SupplierStat(String supplierID, String supplierName, int contact){
        this.supplierID = supplierID;
        this.supplierName = supplierName;
        this.contact = contact;
        //this.unitPrice = unitPrice;
        //this.category = category;
        //this.supplierID = supplierID;
        //this.dateAdded = dateAdded;
    }
    
    public String getSupplierID() {
        return supplierID;
    }
    
    public String getSupplierName() {
        return supplierName;
    }
    
    public int getContact() {
        return contact;
    }
}
